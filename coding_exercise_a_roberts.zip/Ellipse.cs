﻿using System;
namespace spreadex_exercise
{
    // class name
    public class Ellipse
    {
        // Instance Variables
        // parameter names
        String _name = "";
        int _diameterH = 0;
        int _diameterV = 0;
        int[] _centre = new int[2];

        // inputs from main
        public Ellipse(String name, int diameterH,
            int diameterV, int[] centre)
        {
            // assigning inputs to class variables
            _name = name;
            _diameterH = diameterH;
            _diameterV = diameterV;
            _centre = centre;
        }

        // Output
        public String toString()
        {
            // converting vector to string and printing to main
            return (_name + " (" + String.Join(",", _centre)
                + ") diameterH=" + _diameterH + " diameterV=" + _diameterV);
        }
    }
}
