﻿using System;
namespace spreadex_exercise
{
    // class name
    public class Circle
    {
        // Instance Variables
        // parameter names
        String _name = "";
        int _size = 0;
        int[] _centre = new int[2];

        // inputs from main
        public Circle(String name, int size, int[] centre)
        {
            // assigning inputs to class variables
            _name = name;
            _size = size;
            _centre = centre;
        }

        // Output
        public String toString()
        {
            // converting vector to string and printing to main
            return (_name + " (" + String.Join(",", _centre)
                + ") size=" + _size) ;
        }
    }
}
