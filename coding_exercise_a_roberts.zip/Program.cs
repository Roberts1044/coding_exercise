﻿using System;

// widgets - separate .cs files for each class
// rectangle (10,10) width=30, height=40
// square (15,30) size=35
// ellipse (100,150) diameterH=300, diameterV=200
// circle (1,1) size=300
// textbox (5,5) width=200, height=100, text="sample text"

// program to print key details of each drawing to console
// no need to render widgets, no user input
// console application main() method for testing


// exercise name
namespace spreadex_exercise
{
    // class name
    class Program
    {
        // main method
        static void Main(string[] args)
        {
            // Instance Variables
            // widget centres
            int[] rectangleCentre = new int[] { 10, 10 };
            int[] squareCentre = new int[] { 15, 30 };
            int[] ellipseCentre = new int[] { 100, 150 };
            int[] circleCentre = new int[] { 1, 1 };
            int[] textboxCentre = new int[] { 5, 5 };

            // header image
            Console.WriteLine("----------------------------------------------------------------");
            Console.WriteLine("Requested Drawing");
            Console.WriteLine("----------------------------------------------------------------");

            // Creating Drawings

            // call rectangle class
            Rectangle rectangle = new Rectangle("Rectangle", 30, 40, rectangleCentre);
            // print created rectangle class
            Console.WriteLine(rectangle.toString());

            // call square class
            Square square = new Square("Square", 35, squareCentre);
            // print created square class
            Console.WriteLine(square.toString());

            // call ellipse class
            Ellipse ellipse = new Ellipse("Ellipse", 300, 200, ellipseCentre);
            // print created ellipse class
            Console.WriteLine(ellipse.toString());

            // call circle class
            Circle circle = new Circle("Circle", 300, circleCentre);
            // print created circle class
            Console.WriteLine(circle.toString());

            // call textbox class
            Textbox textbox = new Textbox("Textbox", 200, 100, textboxCentre, "sample text");
            // print created textbox class
            Console.WriteLine(textbox.toString());

            // footer image
            Console.WriteLine("----------------------------------------------------------------");


            // square and circle classes are identical
            // principles of rectangle and ellipse classes are identical, terminology differs
            // textbox class is rectangle class amended for text field
            // all five shapes could be alamgamated into one class with proviso for width = height and null text field
        }
    }
}
