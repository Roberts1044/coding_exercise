﻿using System;
namespace spreadex_exercise
{
    // class name
    public class Textbox
    {
        // Instance Variables
        // parameter names
        String _name = "";
        int _width = 0;
        int _height = 0;
        int[] _centre = new int[2];
        String _text = "";

        // inputs from main
        public Textbox(String name, int width,
            int height, int[] centre, String text)
        {
            // assigning inputs to class variables
            _name = name;
            _width = width;
            _height = height;
            _centre = centre;
            _text = text;
        }

        // Output
        public String toString()
        {
            // converting vector to string and printing to main
            return (_name + " (" + String.Join(",", _centre)
                + ") width=" + _width + " height=" + _height
                + " Text=\"" + _text + "\"");
        }
    }
}
